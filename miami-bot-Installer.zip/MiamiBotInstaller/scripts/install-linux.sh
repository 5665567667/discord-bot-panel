#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-$HOME/MiamiBot}"
mkdir -p "$TARGET"
command -v python3 >/dev/null || { echo "Установите Python 3.11+"; exit 1; }
python3 -m venv "$TARGET/.venv"
echo "Создано окружение: $TARGET/.venv"
echo "После добавления файлов проекта установите зависимости: $TARGET/.venv/bin/pip install -r $TARGET/requirements.txt"
