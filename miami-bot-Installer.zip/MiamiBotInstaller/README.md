# Miami Bot Installer — Test Source
Самостоятельный WPF-инсталлятор под Windows (.NET 8).

GitHub: https://github.com/5665567667/discord-bot-panel

Функции: GitHub Releases update check, online ZIP download, offline ZIP fallback,
SHA-256 verification, staging, backup/rollback, сохранение .env/data/logs/config,
редактор .env, журнал, проверка файлов, запуск main.py.

ВАЖНО: на момент подготовки в GitHub-репозитории есть только README.md и нет Releases.
Для реальной установки опубликуйте Release с `MiamiBot.zip` и `miami-manifest.json`.
Офлайн-архив положите в `OfflinePayload/MiamiBot.zip`.

Сборка:
`dotnet publish src/MiamiBot.Installer/MiamiBot.Installer.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true`

WPF-инсталлятор работает на Windows. Для Linux есть отдельный скрипт.
Не коммитьте `.env` и Discord Token в GitHub.
