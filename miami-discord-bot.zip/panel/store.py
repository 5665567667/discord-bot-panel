import os
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
import datetime

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///miami_bot.db")

Base = declarative_base()
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(Integer, primary_key=True, index=True)
    discord_id = Column(String(50), unique=True, index=True)
    username = Column(String(100))
    avatar = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class LogEntry(Base):
    __tablename__ = "logs"
    id = Column(Integer, primary_key=True, index=True)
    action = Column(String(50))
    user = Column(String(100))
    guild_id = Column(String(50))
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class WarningEntry(Base):
    __tablename__ = "warnings"
    id = Column(Integer, primary_key=True, index=True)
    guild_id = Column(String(50))
    user_id = Column(String(50))
    moderator = Column(String(100))
    reason = Column(Text)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)

def add_log(action: str, user: str, guild_id: str, details: str = ""):
    db = SessionLocal()
    try:
        log = LogEntry(action=action, user=user, guild_id=guild_id, details=details)
        db.add(log)
        db.commit()
    finally:
        db.close()

def add_warning(guild_id: str, user_id: str, moderator: str, reason: str):
    db = SessionLocal()
    try:
        warn = WarningEntry(guild_id=guild_id, user_id=user_id, moderator=moderator, reason=reason)
        db.add(warn)
        db.commit()
    finally:
        db.close()

def get_warnings(guild_id: str, user_id: str):
    db = SessionLocal()
    try:
        rows = db.query(WarningEntry).filter(WarningEntry.guild_id == guild_id, WarningEntry.user_id == user_id).all()
        return [{"id": r.id, "reason": r.reason, "moderator": r.moderator} for r in rows]
    finally:
        db.close()
