import os
import httpx
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from panel.store import init_db, SessionLocal, UserSession, LogEntry

# Загрузка конфигураций из .env
DISCORD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "")
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "")
DISCORD_REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "http://127.0.0")
GUILD_ID = os.getenv("GUILD_ID", "")
REQUIRED_ROLE_NAME = "DB"  # Название роли для проверки доступа
BOT_TOKEN = os.getenv("DISCORD_TOKEN", "")

app = FastAPI(title="Miami Bot Control Panel")

# Настройка сессий для авторизации (COOKIE)
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET", "super-secret-key-miami"))
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def startup_event():
    # Автоматическое создание таблиц в базе данных при старте
    init_db()

@app.get("/login")
def login():
    # Перенаправление пользователя на страницу авторизации Discord OAuth2
    discord_login_url = (
        f"https://discord.com"
        f"?client_id={DISCORD_CLIENT_ID}"
        f"&redirect_uri={DISCORD_REDIRECT_URI}"
        f"&response_type=code"
        f"&scope=identify%20guilds%20guilds.members.read"
    )
    return RedirectResponse(discord_login_url)

@app.get("/auth/callback")
async def auth_callback(request: Request, code: str = None):
    if not code:
        raise HTTPException(status_code=400, detail="Missing authorization code")

    # 1. Обмениваем код авторизации на Access Token
    async with httpx.AsyncClient() as client:
        token_response = await client.post(
            "https://discord.com",
            data={
                "client_id": DISCORD_CLIENT_ID,
                "client_secret": DISCORD_CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": DISCORD_REDIRECT_URI,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        if token_response.status_code != 200:
            return JSONResponse(status_code=400, content={"error": "Failed to verify code with Discord"})
        
        tokens = token_response.json()
        access_token = tokens["access_token"]

        # 2. Получаем базовую информацию о вошедшем пользователе
        user_response = await client.get(
            "https://discord.com",
            headers={"Authorization": f"Bearer {access_token}"}
        )
        user_data = user_response.json()
        discord_id = user_data["id"]

        # 3. Проверяем наличие роли @DB у пользователя на сервере через Bot API
        member_response = await client.get(
            f"https://discord.com{GUILD_ID}/members/{discord_id}",
            headers={"Authorization": f"Bot {BOT_TOKEN}"}
        )
        
        if member_response.status_code != 200:
            raise HTTPException(status_code=403, detail="Вы не являетесь участником нужного Discord-сервера.")
        
        member_data = member_response.json()
        user_roles_ids = member_data.get("roles", [])

        # Получаем список всех ролей сервера, чтобы узнать ID роли с именем "DB"
        guild_roles_response = await client.get(
            f"https://discord.com{GUILD_ID}/roles",
            headers={"Authorization": f"Bot {BOT_TOKEN}"}
        )
        guild_roles = guild_roles_response.json()
        
        target_role_id = next((r["id"] for r in guild_roles if r["name"] == REQUIRED_ROLE_NAME), None)

        # Если такой роли на сервере нет или у пользователя её нет в списке — отклоняем
        if not target_role_id or target_role_id not in user_roles_ids:
            raise HTTPException(status_code=403, detail=f"Доступ запрещен. У вас отсутствует роль @{REQUIRED_ROLE_NAME}")

        # 4. Сохраняем или обновляем сессию пользователя в SQLite
        db = SessionLocal()
        user_session = db.query(UserSession).filter(UserSession.discord_id == discord_id).first()
        if not user_session:
            user_session = UserSession(discord_id=discord_id, username=user_data["username"], avatar=user_data.get("avatar"))
            db.add(user_session)
        else:
            user_session.username = user_data["username"]
            user_session.avatar = user_data.get("avatar")
        db.commit()
        db.close()

        # Записываем данные в куки сессии браузера
        request.session["user"] = {"id": discord_id, "username": user_data["username"]}
        
        # Перенаправляем на страницу панели управления
        return RedirectResponse(url="/dashboard")

@app.get("/dashboard")
async def dashboard(request: Request):
    # Страница доступна только после успешной авторизации
    user = request.session.get("user")
    if not user:
        return RedirectResponse(url="/login")
    
    # Отдаем красивую HTML-страницу с логами
    return FileResponse("panel/static/index.html")

# ==============================================================================
# ИНТЕГРИРОВАННОЕ API ДЛЯ ПОЛУЧЕНИЯ ЛОГОВ ИЗ БАЗЫ ДАННЫХ
# ==============================================================================
@app.get("/api/logs")
async def get_bot_logs(request: Request):
    # Строгая проверка авторизации перед выдачей данных из БД
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Неавторизован")
        
    db = SessionLocal()
    try:
        # Извлекаем последние 50 записей аудита, сортируя от свежих к старым
        logs = db.query(LogEntry).order_by(LogEntry.timestamp.desc()).limit(50).all()
        return [
            {
                "id": log.id,
                "action": log.action,
                "user": log.user,
                "details": log.details,
                "timestamp": log.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            }
            for log in logs
        ]
    finally:
        db.close()

@app.get("/logout")
async def logout(request: Request):
    # Очищаем сессию и разлогиниваем пользователя
    request.session.clear()
    return RedirectResponse(url="/login")

if __name__ == "__main__":
    import uvicorn
    # Динамическое чтение порта из .env, по умолчанию 8000
    panel_port = int(os.getenv("PORT", 8000)) 
    uvicorn.run("panel.app:app", host="127.0.0.1", port=panel_port, reload=True)
