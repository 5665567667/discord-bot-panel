"""Добровольный клиент телеметрии. Не запускает произвольные удалённые команды."""
import argparse, os, platform, socket, time, uuid, sys
import psutil, httpx

def main():
    p = argparse.ArgumentParser(description="Miami Discord Bot — клиент участника")
    p.add_argument("--server", required=True, help="Адрес панели, например https://bot.example.com")
    p.add_argument("--code", required=True, help="Код подключения от администратора")
    p.add_argument("--interval", type=int, default=15, help="Интервал отправки метрик в секундах")
    args = p.parse_args()
    base = args.server.rstrip("/")
    name = socket.gethostname()
    os_name = f"{platform.system()} {platform.release()}"
    with httpx.Client(timeout=10) as client:
        r = client.post(base + "/api/enroll", json={"code": args.code, "name": name, "os": os_name})
        r.raise_for_status()
        credential = r.json()["device_id"]
        print("Устройство зарегистрировано. Нажмите Ctrl+C для отключения.")
        try:
            while True:
                cpu = psutil.cpu_percent(interval=1)
                ram = psutil.virtual_memory().percent
                body = {"device_id": credential, "name": name, "os": os_name,
                        "cpu_percent": cpu, "ram_percent": ram}
                response = client.post(base + "/api/heartbeat", json=body,
                                       headers={"Authorization": "Bearer " + credential})
                if response.status_code == 401:
                    print("Сеанс не авторизован; завершение.")
                    return
                response.raise_for_status()
                print(f"CPU {cpu:.0f}% | RAM {ram:.0f}% — сигнал отправлен")
                time.sleep(max(5, args.interval))
        except KeyboardInterrupt:
            print("\nКлиент остановлен пользователем.")
if __name__ == "__main__":
    main()
