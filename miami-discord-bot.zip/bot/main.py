import os, sys, asyncio
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import discord
from discord import app_commands, ui
from discord.ext import commands
from dotenv import load_dotenv
from datetime import timedelta
from collections import Counter
from panel.store import init_db, add_log, add_warning, get_warnings, get_stats

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "")
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)
LOGS_CHANNEL_ID = int(os.getenv("LOGS_CHANNEL_ID", "0") or 0)

intents = discord.Intents.default()
intents.members = True
intents.message_content = True  # Включено для чтения текста команд и отслеживания удаления сообщений

class MiamiBot(commands.Bot):
    async def setup_hook(self):
        init_db()
        # Регистрируем View для персистентных (постоянных) кнопок тикетов, чтобы они работали после перезапуска
        self.add_view(TicketCreateView())
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

bot = MiamiBot(command_prefix="!", intents=intents)

def audit(interaction: discord.Interaction, action: str, details: str = ""):
    add_log(action, str(interaction.user), str(interaction.guild_id or ""), details)

@bot.event
async def on_ready():
    print(f"Бот подключён: {bot.user} ({bot.user.id})")
    add_log("bot_online", str(bot.user), "", "Бот подключился к Discord")

# ==============================================================================
# 1. ЛОГИРОВАНИЕ ИЗМЕНЕНИЯ РОЛЕЙ И НИКНЕЙМОВ
# ==============================================================================
@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    logs_channel = bot.get_channel(LOGS_CHANNEL_ID)
    if not logs_channel:
        return

    # Проверка изменения ролей
    if before.roles != after.roles:
        added_roles = [role for role in after.roles if role not in before.roles and not role.is_default()]
        removed_roles = [role for role in before.roles if role not in after.roles and not role.is_default()]
        
        if added_roles or removed_roles:
            embed = discord.Embed(title="Изменение ролей", color=0x8B5CF6)
            embed.set_author(name=f"GTA 5 RP | Factions", icon_url=after.guild.icon.url if after.guild.icon else None)
            embed.add_field(name="Пользователь:", value=after.mention, inline=False)
            embed.add_field(name="Ник до / после:", value=f"{before.display_name} ➔ {after.display_name}", inline=False)
            
            res_text = ""
            for r in added_roles:
                res_text += f"🔹 **Добавлена роль:** {r.mention}\n"
            for r in removed_roles:
                res_text += f"🔸 **Удалена роль:** {r.mention}\n"
                
            embed.add_field(name="Результат:", value=res_text, inline=False)
            
            moderator = "Неизвестно (Автоматически)"
            try:
                async for entry in after.guild.audit_logs(limit=1, action=discord.AuditLogAction.member_role_update):
                    if entry.target.id == after.id:
                        moderator = entry.user.mention
                        break
            except Exception:
                pass
                
            embed.add_field(name="Автор:", value=moderator, inline=False)
            embed.timestamp = discord.utils.utcnow()
            await logs_channel.send(content=after.mention, embed=embed)

    # Проверка изменения серверного никнейма (до смены и после смены личного серверного никнейма)
    if before.display_name != after.display_name:
        embed = discord.Embed(title="📝 Изменение серверного никнейма", color=0x3B82F6, timestamp=discord.utils.utcnow())
        embed.set_author(name=f"{after} ({after.id})", icon_url=after.avatar.url if after.avatar else after.default_avatar.url)
        embed.add_field(name="Старый никнейм:", value=f"`{before.display_name}`", inline=True)
        embed.add_field(name="Новый никнейм:", value=f"`{after.display_name}`", inline=True)
        embed.add_field(name="Упоминание:", value=after.mention, inline=False)
        await logs_channel.send(embed=embed)

# ==============================================================================
# 2. АВТОМОДЕРАЦИЯ (НАРОДНОЕ ГОЛОСОВАНИЕ И ОГРАНИЧЕНИЕ ПРАВ)
# ==============================================================================
class VoteButtons(ui.View):
    def __init__(self, violator: discord.Member, reason: str):
        super().__init__(timeout=1800)  # 30 минут таймер голосования
        self.violator = violator
        self.reason = reason
        self.votes = {}

    async def register_vote(self, interaction: discord.Interaction, choice: str):
        self.votes[interaction.user.id] = choice
        await interaction.response.send_message(f"Вы проголосовали за: **{choice}**", ephemeral=True)

    @ui.button(label="Оправдать", style=discord.ButtonStyle.success)
    async def forgive(self, interaction: discord.Interaction, button: ui.Button):
        await self.register_vote(interaction, "Оправдать")

    @ui.button(label="Мут на 1 час", style=discord.ButtonStyle.danger)
    async def mute_1h(self, interaction: discord.Interaction, button: ui.Button):
        await self.register_vote(interaction, "Мут 1 час")

    @ui.button(label="Варн (Предупреждение)", style=discord.ButtonStyle.secondary)
    async def warn_vote(self, interaction: discord.Interaction, button: ui.Button):
        await self.register_vote(interaction, "Варн")

@bot.tree.command(name="punish_vote", description="Запустить народное голосование против нарушителя")
@app_commands.checks.has_permissions(moderate_members=True)
async def punish_vote(interaction: discord.Interaction, user: discord.Member, reason: str):
    await interaction.response.send_message(f"Голосование против {user.mention} запущено на 30 минут.", ephemeral=True)
    
    # Забираем право писать во всех чатах (Таймаут/Мут на время голосования)
    try:
        await user.timeout(timedelta(minutes=30), reason="Народное голосование (ограничение прав)")
    except Exception:
        pass

    embed = discord.Embed(title="🚨 Народное голосование за нарушение", color=0xFF0000)
    embed.add_field(name="Нарушитель", value=f"Ник: {user.mention}\nИмя в Discord: `{user.name}`\nСерверный ник: `{user.display_name}`")
    embed.add_field(name="Суть нарушения", value=reason, inline=False)
    embed.set_footer(text="Голосование автоматически завершится через 30 минут")

    view = VoteButtons(user, reason)
    await interaction.channel.send(embed=embed, view=view)
    
    await asyncio.sleep(1800)  # Ожидание 30 минут до конца голосования
    view.stop()
    
    results = list(view.votes.values())
    if not results:
        try: await user.timeout(None)
        except Exception: pass
        return await interaction.channel.send(f"Голосование по делу {user.mention} завершено. Нет проголосовавших. Права возвращены.")

    counts = Counter(results)
    most_common = counts.most_common()
    
    # Если получается одинаковое количество голосов (ничья) — пинг администрации
    if len(most_common) > 1 and most_common[0][1] == most_common[1][1]:
        try: await user.timeout(None)
        except Exception: pass
        return await interaction.channel.send(f"⚠️ Ничья в голосовании по делу {user.mention}! Окончательное решение за Администрацией. @everyone")

    winner_choice = most_common[0][0]
    
    if winner_choice == "Оправдать":
        try: await user.timeout(None)
        except Exception: pass
        await interaction.channel.send(f"✅ Большинство оправдало {user.mention}. Ограничение на общение снято.")
    elif winner_choice == "Мут 1 час":
        try: await user.timeout(timedelta(hours=1), reason="Решение народного голосования")
        except Exception: pass
        await interaction.channel.send(f"⏳ Решением большинства {user.mention} отправлен в мут на 1 час.")
    elif winner_choice == "Варн":
        try: await user.timeout(None)
        except Exception: pass
        add_warning(str(interaction.guild_id), str(user.id), "Народный суд", reason)
        await interaction.channel.send(f"⚠️ Решением большинства {user.mention} получает предупреждение (варн).")

# ==============================================================================
# 3. ТТИКЕТ-СИСТЕМА С ТАЙМЕРОМ ЗАКРЫТИЯ
# ==============================================================================
class TicketCloseButton(ui.View):
    def __init__(self, creator_id: int):
        super().__init__(timeout=None)
        self.creator_id = creator_id

    @ui.button(label="🔒 Закрыть тикет", style=discord.ButtonStyle.danger, custom_id="close_ticket_btn")
    async def close(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.creator_id and not interaction.user.guild_permissions.manage_threads:
            return await interaction.response.send_message("Только создатель тикета или администратор может закрыть его.", ephemeral=True)
        
        # Запуск таймера на 2 минуты в отдельное сообщение
        await interaction.response.send_message("⏳ Проблема решена. Этот тикет закроется автоматически через 2 минуты.", ephemeral=False)
        await asyncio.sleep(120)
        
        if isinstance(interaction.channel, discord.Thread):
            await interaction.channel.edit(locked=True, archived=True)

class TicketCreateView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="✉️ Открыть тикет", style=discord.ButtonStyle.primary, custom_id="create_ticket_permanent")
    async def create(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        # Открывается приватная ветка
        thread = await interaction.channel.create_thread(
name=f"тикет-{interaction.user.name}",
type=discord.ChannelType.private_thread
)
await thread.add_user(interaction.user)
# Пингуются все администраторы и роли через @everyone / настроенные роли
await thread.send(f"🔔 Панель поддержки. Пользователь {interaction.user.mention} открыл обращение.\n@everyone Внимание администрации!", view=TicketCloseButton(interaction.user.id))
await interaction.followup.send(f"Ветка поддержки успешно создана: {thread.mention}", ephemeral=True)
@bot.tree.command(name="setup_tickets", description="Создать панель открытия тикетов")
@app_commands.checks.has_permissions(administrator=True)
async def setup_tickets(interaction: discord.Interaction):
embed = discord.Embed(title="🎫 Техническая поддержка фракции", description="Если у вас появились вопросы или проблемы, нажмите на кнопку ниже для связи с администрацией.", color=0x8B5CF6)
await interaction.channel.send(embed=embed, view=TicketCreateView())
await interaction.response.send_message("Панель тикетов установлена.", ephemeral=True)

==============================================================================


4. ПРИВЕТСТВИЯ И ПРОЩАНИЯ УЧАСТНИКОВ


==============================================================================

@bot.event
async def on_member_join(member: discord.Member):
channel = member.guild.system_channel or bot.get_channel(LOGS_CHANNEL_ID)
if channel:
embed = discord.Embed(title=f"👋 Приветствуем, {member.name}!", description=f"Добро пожаловать на сервер фракции {member.guild.name}! Ознакомься с правилами и приятной игры.", color=0x10B981)
embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
await channel.send(embed=embed)
@bot.event
async def on_member_remove(member: discord.Member):
channel = member.guild.system_channel or bot.get_channel(LOGS_CHANNEL_ID)
if channel:
embed = discord.Embed(title=f"🏃‍♂️ До свидания, {member.name}!", description="Покинул сервер фракции. Ждем возвращения обратно!", color=0xEF4444)
embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
await channel.send(embed=embed)

==============================================================================


5. СИСТЕМА АНКЕТ И ВЫДАЧИ ПОД-РОЛЕЙ


==============================================================================

class RoleSelectionView(ui.View):
def init(self, applicant: discord.Member):
super().init(timeout=None)
self.applicant = applicant
# Окошко с кнопками ролей и их названиями после заполнения анкеты и одобрения
@ui.button(label="Установить роль: Офицер", style=discord.ButtonStyle.primary)
async def role_one(self, interaction: discord.Interaction, button: ui.Button):
role = interaction.guild.get_role(123456789012345678) # Замени на ID роли на своем сервере
if role: await self.applicant.add_roles(role)
await interaction.response.send_message(f"Основная роль выдана.", ephemeral=True)
@ui.button(label="Установить под-роль: Спец. Отдел", style=discord.ButtonStyle.secondary)
async def role_two(self, interaction: discord.Interaction, button: ui.Button):
role = interaction.guild.get_role(876543210987654321) # Замени на ID под-роли на своем сервере
if role: await self.applicant.add_roles(role)
await interaction.response.send_message(f"Под-роль успешно настроена.", ephemeral=True)
class FormReviewButtons(ui.View):
def init(self, applicant: discord.Member, answers: str):
super().init(timeout=None)
self.applicant = applicant
self.answers = answers
@ui.button(label="Одобрить", style=discord.ButtonStyle.success)
async def approve(self, interaction: discord.Interaction, button: ui.Button):
await interaction.response.send_message(f"Анкета одобрена.", ephemeral=True)
try:
# Как только админ одобрит — выдавать окошко с кнопками ролей пользователю
await self.applicant.send("🎉 Ваша анкета была успешно одобрена администратором фракции! Выберите ваши роли и под-роли с помощью кнопок ниже:", view=RoleSelectionView(self.applicant))
except Exception:
await interaction.channel.send(f"Не удалось отправить ЛС {self.applicant.mention}, вывожу селектор ролей сюда:", view=RoleSelectionView(self.applicant))
@ui.button(label="Отклонить", style=discord.ButtonStyle.danger)
async def deny(self, interaction: discord.Interaction, button: ui.Button):
await interaction.response.send_message("Анкета отклонена.", ephemeral=True)
try: await self.applicant.send("Ваша анкета на вступление во фракцию была отклонена администрацией.")
except Exception: pass
@bot.tree.command(name="submit_form", description="Заполнить анкету на вступление")
async def submit_form(interaction: discord.Interaction, nickname: str, age: int, info: str):
await interaction.response.send_message("Ваша анкета отправлена на проверку администрации!", ephemeral=True)
logs_channel = bot.get_channel(LOGS_CHANNEL_ID)
if logs_channel:
embed = discord.Embed(title="📋 Новая анкета на вступление", color=0xFBBF24)
embed.add_field(name="Отправитель", value=interaction.user.mention)
embed.add_field(name="Никнейм игрока", value=nickname)
embed.add_field(name="Возраст", value=str(age))
embed.add_field(name="Информация / Опыт", value=info, inline=False)
await logs_channel.send(embed=embed, view=FormReviewButtons(interaction.user, f"{nickname}, {age}"))

==============================================================================


6. АВТОМАТИЧЕСКОЕ ЛОГИРОВАНИЕ УДАЛЕННЫХ СООБЩЕНИЙ В ОТДЕЛЬНЫЙ ЧАТ


==============================================================================

@bot.event
async def on_message_delete(message: discord.Message):
if message.author.bot or not message.guild:
return
logs_channel = bot.get_channel(LOGS_CHANNEL_ID)
if not logs_channel or message.channel.id == LOGS_CHANNEL_ID:
return
embed = discord.Embed(title="🗑️ Сообщение удалено", color=0xEF4444, timestamp=discord.utils.utcnow())
embed.set_author(name=f"{message.author} ({message.author.id})", icon_url=message.author.avatar.url if message.author.avatar else message.author.default_avatar.url)
content = message.content if message.content else "[Текст отсутствовал или это было только медиа-вложение]"
if len(content) > 1024:
content = content[:1021] + "..."
embed.add_field(name="Автор:", value=message.author.mention, inline=True)
embed.add_field(name="Канал:", value=message.channel.mention, inline=True)
embed.add_field(name="Старое содержимое текста:", value=content, inline=False)
if message.attachments:
files_info = "\n".join(f"📎 {att.filename}" for att in message.attachments)
embed.add_field(name="Вложения:", value=files_info, inline=False)
first_att = message.attachments[0]
if first_att.content_type and first_att.content_type.startswith("image/"):
embed.set_image(url=first_att.url)
deleter = "Неизвестно (Сам автор или очистка ботом)"
try:
async for entry in message.guild.audit_logs(limit=1, action=discord.AuditLogAction.message_delete):
if entry.target.id == message.author.id and entry.extra.channel.id == message.channel.id:
deleter = entry.user.mention
break
except Exception:
pass
embed.add_field(name="Кто удалил:", value=deleter, inline=False)
await logs_channel.send(embed=embed)
add_log("message_delete", str(message.author), str(message.guild.id), f"Канал: #{message.channel.name} | Текст: {content[:200]}")

==============================================================================


СТАНДАРТНЫЕ БАЗОВЫЕ КОМАНДЫ И ОБРАБОТЧИК ОШИБОК


==============================================================================

@bot.tree.command(name="ping", description="Проверить задержку бота")
async def ping(interaction: discord.Interaction):
await interaction.response.send_message(f"🏓 Pong! Задержка: {round(bot.latency * 1000)} мс", ephemeral=True)
@bot.tree.command(name="stats", description="Статистика текущего Discord-сервера")
async def stats(interaction: discord.Interaction):
if not interaction.guild:
return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)
g = interaction.guild
embed = discord.Embed(title=f"Статистика — {g.name}", color=0x8B5CF6)
embed.add_field(name="Участники", value=str(g.member_count or "—"))
embed.add_field(name="Каналы", value=str(len(g.channels)))
embed.add_field(name="Роли", value=str(len(g.roles)))
embed.add_field(name="Задержка", value=f"{round(bot.latency*1000)} мс")
await interaction.response.send_message(embed=embed, ephemeral=True)
audit(interaction, "stats", g.name)
@bot.tree.command(name="clear", description="Удалить последние сообщения в канале")
@app_commands.checks.has_permissions(manage_messages=True)
@app_commands.describe(amount="Количество сообщений (1–100)")
async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
if not isinstance(interaction.channel, (discord.TextChannel, discord.Thread)):
return await interaction.response.send_message("Эта команда доступна только в текстовом канале.", ephemeral=True)
await interaction.response.defer(ephemeral=True)
deleted = await interaction.channel.purge(limit=amount)
await interaction.followup.send(f"🧹 Удалено сообщений: {len(deleted)}", ephemeral=True)
audit(interaction, "clear", f"Удалено: {len(deleted)}")
@bot.tree.command(name="kick", description="Исключить участника")
@app_commands.checks.has_permissions(kick_members=True)
async def kick(interaction: discord.Interaction, user: discord.Member, reason: str = "Причина не указана"):
if user == interaction.user:
return await interaction.response.send_message("Нельзя исключить самого себя.", ephemeral=True)
await user.kick(reason=f"{interaction.user}: {reason}")
await interaction.response.send_message(f"👢 {user} исключён. Причина: {reason}")
audit(interaction, "kick", f"{user} | {reason}")
@bot.tree.command(name="ban", description="Заблокировать участника")
@app_commands.checks.has_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, user: discord.Member, reason: str = "Причина не указана"):
if user == interaction.user:
return await interaction.response.send_message("Нельзя заблокировать самого себя.", ephemeral=True)
await user.ban(reason=f"{interaction.user}: {reason}")
await interaction.response.send_message(f"🔨 {user} заблокирован. Причина: {reason}")
audit(interaction, "ban", f"{user} | {reason}")
@bot.tree.command(name="panel", description="Показать адрес панели управления")
async def panel_link(interaction: discord.Interaction):
url = os.getenv("API_PUBLIC_URL", "http://127.0.0.1:8000")
await interaction.response.send_message(f"Панель управления: {url}", ephemeral=True)
@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
msg = "Недостаточно прав для этой команды." if isinstance(error, app_commands.MissingPermissions) else "Команда завершилась ошибкой."
if interaction.response.is_done():
await interaction.followup.send(msg, ephemeral=True)
else:
await interaction.response.send_message(msg, ephemeral=True)
add_log("command_error", str(interaction.user), str(interaction.guild_id or ""), repr(error))
if name == "main":
if not TOKEN or TOKEN.startswith("PASTE_"):
raise SystemExit("Заполните DISCORD_TOKEN в файле .env")
bot.run(TOKEN)