@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
if not exist .venv\Scripts\activate.bat (
 echo Сначала запустите scripts\install_windows.bat
 pause
 exit /b 1
)
call .venv\Scripts\activate.bat
if not exist .env (
 echo Не найден .env. Скопируйте .env.example в .env и заполните настройки.
 pause
 exit /b 1
)
start "Miami Panel" cmd /k "call .venv\Scripts\activate.bat && python -m uvicorn panel.app:app --host 127.0.0.1 --port 8000"
python -m bot.main
