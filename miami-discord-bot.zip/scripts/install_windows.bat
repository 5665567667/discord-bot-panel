@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
echo ========================================
echo    Установка Miami Discord Bot
echo ========================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python не найден. Установите Python 3.11 или новее и включите Add Python to PATH.
  pause
  exit /b 1
)
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
if not exist data mkdir data
echo.
echo Установка завершена. Настройте .env и запустите start_windows.bat
pause
