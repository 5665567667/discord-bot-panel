#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
[ -f .env ] || { echo "Сначала скопируйте .env.example в .env и заполните настройки"; exit 1; }
. .venv/bin/activate
python -m uvicorn panel.app:app --host 127.0.0.1 --port 8000 &
PANEL_PID=$!
trap 'kill "$PANEL_PID" 2>/dev/null || true' EXIT INT TERM
python -m bot.main
