#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
command -v python3 >/dev/null || { echo "Установите Python 3.11+ и python3-venv"; exit 1; }
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
mkdir -p data
echo "Установка завершена. Отредактируйте .env и выполните bash scripts/start_linux.sh"
